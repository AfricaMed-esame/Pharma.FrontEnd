$(function () {
    $('#mainTable').editableTableWidget({ editor: $('<input>'), preventColumns: [2, 3] });
});