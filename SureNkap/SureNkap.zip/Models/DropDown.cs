﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SureNkap.Models
{
    public class DropDown
    {
        public string Name { get; set; }
        public int Id { get; set; }
    }
}